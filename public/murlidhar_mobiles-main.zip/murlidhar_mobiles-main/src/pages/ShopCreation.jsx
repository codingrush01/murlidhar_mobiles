import { useState, useRef, useEffect } from "react";
import { db } from "../utils/firebase";
import { collection, addDoc, onSnapshot, query, orderBy, deleteDoc, doc, updateDoc, where, getDocs } from "firebase/firestore";
import { toast } from "sonner";
import gsap from "gsap";
import { useGSAP } from "@gsap/react";
import { Plus, Trash2, Store, MapPin, Phone, Mail, Loader2, Pencil, AlertTriangle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import SettingsDialog from "@/components/SettingsDialog";
import { getAuth, onAuthStateChanged } from "firebase/auth";

export default function ShopCreation({ darkMode, setDarkMode }) {
  const container = useRef(null);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [shopToDelete, setShopToDelete] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [shops, setShops] = useState([]);
  const [formData, setFormData] = useState({ shopName: "", address: "", number: "", email: "" });
  const [userShopId, setUserShopId] = useState(null);
  const [isShopUser, setIsShopUser] = useState(false);
  const [settings, setSettings] = useState({ shops_limit: 3 });

  // Persist dark mode
  useEffect(() => {
    const saved = localStorage.getItem("darkMode");
    if (saved !== null) setDarkMode(JSON.parse(saved));
  }, [setDarkMode]);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
  }, [darkMode]);

  useEffect(() => {
    return onSnapshot(doc(db, "settings", "global"), (snap) => {
      if (snap.exists()) setSettings(snap.data());
    });
  }, []);

  const shopsLimit = settings?.shops_limit ?? 3;
  const reachedLimit = shops.length >= shopsLimit;

  // Auth listener
  useEffect(() => {
    const auth = getAuth();
    const unsub = onAuthStateChanged(auth, async (u) => {
      if (!u) {
        setUserShopId(null);
        setIsShopUser(false);
        return;
      }
      const q = query(collection(db, "shops"), where("email", "==", u.email));
      const snap = await getDocs(q);
      if (!snap.empty) {
        const shopDoc = snap.docs[0];
        setUserShopId(shopDoc.id);
        setIsShopUser(true);
      } else {
        setUserShopId(null);
        setIsShopUser(false);
      }
    });
    return () => unsub();
  }, []);

  // Shops listener
  useEffect(() => {
    const q = query(collection(db, "shops"), orderBy("createdAt", "desc"));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const shopData = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      setShops(isShopUser && userShopId ? shopData.filter(s => s.id === userShopId) : shopData);
    });
    return () => unsubscribe();
  }, [isShopUser, userShopId]);

  // GSAP animation
  useGSAP(() => {
    gsap.from(container.current.children, {
      y: 30,
      opacity: 0,
      stagger: 0.15,
      duration: 1,
      ease: "expo.out",
    });
  }, []);

  const generateShopId = (currentShops) => `SHOP-${String(currentShops.length + 1).padStart(3, "0")}`;

  const validateForm = () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^[0-9]{7,15}$/;
    if (!emailRegex.test(formData.email)) { toast.error("Invalid email"); return false; }
    if (!phoneRegex.test(formData.number)) { toast.error("Invalid phone number"); return false; }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateForm()) return;
    setLoading(true);
    try {
      if (editingId) {
        await updateDoc(doc(db, "shops", editingId), formData);
        toast.success("Shop updated successfully");
      } else {
        const newShopId = generateShopId(shops);
        await addDoc(collection(db, "shops"), {
          shop_id: newShopId,
          normalizedName: formData.shopName.toLowerCase(),
          ...formData,
          createdAt: new Date(),
        });
        toast.success("Shop added successfully!");
      }
      resetForm();
    } catch (error) {
      toast.error(error.message || "Operation failed");
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({ shopName: "", address: "", number: "", email: "" });
    setEditingId(null);
    setOpen(false);
  };

  const handleEdit = (shop) => {
    setFormData({ shopName: shop.shopName, address: shop.address, number: shop.number, email: shop.email });
    setEditingId(shop.id);
    setOpen(true);
  };

  const confirmDelete = async () => {
    if (!shopToDelete) return;
    try {
      await deleteDoc(doc(db, "shops", shopToDelete.id));
      toast.success(`${shopToDelete.shopName} deleted`);
      setShopToDelete(null);
    } catch (error) {
      toast.error(error.message || "Could not delete shop");
    }
  };

  // Reset shopToDelete when dialog closes
  useEffect(() => {
    if (!deleteDialogOpen) setShopToDelete(null);
  }, [deleteDialogOpen]);

  return (
    <div ref={container} className="container-gsap">
      {reachedLimit && (
        <div className="text-sm font-bold text-yellow-500 py-6 px-8 bg-yellow-500/10 flex items-center gap-2">
          <AlertTriangle className="h-6 w-6 stroke-3" />
          You have reached the maximum shop create limit.
        </div>
      )}

      <div className="p-8 max-w-7xl mx-auto space-y-10">
        {/* Header */}
        <div className="flex flex-col sm:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <h1 className="text-4xl font-bold tracking-tight">Shops</h1>
            <p className="text-muted-foreground">Manage your physical retail locations.</p>
          </div>
          <div className="flex gap-2">
            <Dialog open={open} onOpenChange={setOpen}>
              {!isShopUser && !reachedLimit && (
                <DialogTrigger asChild>
                  <Button className="px-4 gap-2 shadow-none active:scale-95 transition-transform">
                    <Plus className="h-5 w-5" />
                    <p className="hidden md:block">Add New Shop</p>
                  </Button>
                </DialogTrigger>
              )}
              <DialogContent className="sm:max-w-[425px] border-none shadow-2xl backdrop-blur-xl bg-background/90">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold">{editingId ? "Edit Shop" : "Register Shop"}</DialogTitle>
                  <DialogDescription>Update outlet details below.</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-5 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Shop Name</Label>
                    <Input disabled={isShopUser} id="name" required value={formData.shopName} onChange={(e) => setFormData({ ...formData, shopName: e.target.value })} className="bg-background/50 shadow-none" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="address">Address</Label>
                    <Input id="address" required value={formData.address} onChange={(e) => setFormData({ ...formData, address: e.target.value })} className="bg-background/50 shadow-none" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" required value={formData.number} onChange={(e) => setFormData({ ...formData, number: e.target.value })} className="bg-background/50 shadow-none" />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="email">Shop Email</Label>
                    <Input disabled={isShopUser} id="email" type="email" required value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} className="bg-background/50 shadow-none" />
                  </div>
                  <Button disabled={loading} className="w-full h-11 rounded-xl shadow-none">
                    {loading ? <Loader2 className="animate-spin mr-2" /> : editingId ? "Update Shop" : "Save Shop"}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
            <SettingsDialog darkMode={darkMode} setDarkMode={setDarkMode} />
          </div>
        </div>

        <hr className="border-border/50" />

        {/* Delete Alert */}
        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent className="border-none shadow-2xl">
            <AlertDialogHeader>
              <div className="flex gap-2 items-center text-left">
                <div className="h-12 w-12 rounded-full bg-destructive/10 flex items-center justify-center">
                  <AlertTriangle className="h-6 w-6 text-destructive" />
                </div>
                <div>
                  <AlertDialogTitle className="text-xl">Are you sure?</AlertDialogTitle>
                  You are about to delete <span className="font-bold text-foreground">"{shopToDelete?.shopName}"</span>.
                </div>
              </div>
              <hr />
              <AlertDialogDescription className="text-base">
                This action <span className="text-destructive font-medium uppercase">cannot be undone</span> and will affect all related categories and inventory items.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="sm:justify-center w-full gap-3 mt-4">
              <AlertDialogCancel className="transition-all bg-ghost border-0 active:scale-95 flex-1 shadow-none">Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={confirmDelete} className="transition-all bg-destructive hover:bg-destructive flex-1 hover:text-destructive-foreground active:scale-95">
                Confirm Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>

        {/* Shop Grid */}
        {shops.length === 0 ? (
          <div className="h-60 flex flex-col items-center justify-center opacity-30">
            <Store className="h-10 w-10 mb-2" />
            <p>No shops found.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {shops.map((shop) => (
              <Card key={shop.id} className="shop-card group border-border/40 hover:border-primary/40 transition-all shadow-none bg-card/30 backdrop-blur-md rounded-3xl overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div className="p-3 bg-primary/10 rounded-2xl group-hover:bg-primary/20 transition-colors">
                      <Store className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-all">
                      <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-blue-500/10 hover:text-blue-500" onClick={() => handleEdit(shop)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-destructive/10 hover:text-destructive" onClick={() => { setShopToDelete(shop); setDeleteDialogOpen(true); }}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <CardTitle className="mt-4 text-xl font-semibold tracking-tight">{shop.shopName}</CardTitle>
                </CardHeader>
                <CardContent className="text-sm space-y-3 text-muted-foreground/90 pb-6">
                  <div className="flex items-center gap-3"><MapPin className="h-4 w-4 opacity-50" /> {shop.address}</div>
                  <div className="flex items-center gap-3"><Phone className="h-4 w-4 opacity-50" /> {shop.number}</div>
                  <div className="flex items-center gap-3"><Mail className="h-4 w-4 opacity-50" /> {shop.email}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
